package com.app.sygictask.ui.home

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import kotlinx.android.synthetic.main.fragment_home.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.IOException
import java.net.URL

class HomeViewModel : ViewModel() {

    var name: String = ""
    var imageLiveData = MutableLiveData<Bitmap?>()

    fun loadImage(url: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val url = URL(url)
                val bmp = BitmapFactory.decodeStream(url.openConnection().getInputStream())

                imageLiveData.postValue(bmp)
            }
            catch (e: IOException) {
                imageLiveData.postValue(null)
            }
        }
    }

}